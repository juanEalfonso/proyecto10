package ed.example.mimapa;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.BitmapDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.sax.TextElementListener;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,GoogleMap.OnMapClickListener  {

    private GoogleMap mMap;
    private final LatLng SAN =new LatLng(12.5853933,-81.7001788);
    private LocationManager locationManager;
    private LocationListener locationListener;
    private LatLng miUbicacion;
    public EditText Buscar1;
    public EditText Buscar2;
    private CheckBox check;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);












        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                try {
                    miUbicacion = new LatLng(location.getLatitude(),location.getLongitude());
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        };

        Buscar1=findViewById(R.id.editTextTextPersonName3);
        Buscar2=findViewById(R.id.editTextTextPersonName4);
        check=findViewById(R.id.checkBox);







       // requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},100);
        revisarPermisos();
    }



























    private void revisarPermisos() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            !=PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        !=PackageManager.PERMISSION_GRANTED )
        {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION},101);
        }
            else
            {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,locationListener);
            }
        }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng position) {
//poniendo marcadores al click
if(check.isChecked()){
                mMap.addMarker(new MarkerOptions().position(position));}

            }
        });
    }





    public void MapaNormal(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }
    public void MapaHibrido(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
    }
    public void MapaSatelite(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
    }

    public void Mapa0(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_NONE);
    }
    public void Mapa1(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
    }
    public void Mapa2(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
    }
    public void Mapa3(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
    }
    public void Mapa4(View view){
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
    }







    public void Limpiar(View view){
        mMap.clear();
    }
    public void addMarker(View view){
        LatLng TEMPlatting = mMap.getCameraPosition().target;

        Marker miMarker =  mMap.addMarker(new MarkerOptions()
                .position(TEMPlatting).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)) );
        miMarker.showInfoWindow();

     //   mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(TEMP_latting,16));




    }


    public void IR_SITIOB(View view){

         if(     Buscar1.getText().length() !=0 && Buscar1.getText().toString() !=""
              && Buscar2.getText().length() !=0 && Buscar2.getText().toString() !=""     )
         {
             String milatitud=Buscar1.getText().toString();
             String milongitud=Buscar2.getText().toString();
             IR_SITIO( milatitud,milongitud);
         }







    }





    public void IR_SITIO(String milatitud,String milongitud){

        double milati=Double.valueOf(milatitud);
        double milong=Double.valueOf(milongitud);

       LatLng MiSitio = new LatLng(milati,milong);

       mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(MiSitio,15));
    }


    public void IR_PARAISO(View view){
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SAN,15));
    }
    public void IR_UBICACION(View view){
        if(miUbicacion == null)
        {
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(miUbicacion,19));}
    }


    public void IR_UD(View view){
        LatLng UD = new LatLng(4.6282007,-74.0658139);

        Marker miMarker =  mMap.addMarker(new MarkerOptions()
                .position(UD).title(" U F J DE C").snippet("universidad")    );
        miMarker.showInfoWindow();

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(UD,16));

    }


    @Override
    public void onMapClick(LatLng latLng) {
        mMap.addMarker(new MarkerOptions().position(latLng).title("Marker"));
    }
}